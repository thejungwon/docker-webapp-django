import pytest
import test_helpers

from django.urls import reverse
from django.test import Client


pytestmark = [pytest.mark.django_db]


def tests_EmailTemplate_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_EmailTemplate()
    instance2 = test_helpers.create_PizzaDeliverySystem_EmailTemplate()
    client = Client()
    url = reverse("PizzaDeliverySystem_EmailTemplate_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_EmailTemplate_create_view():
    M_T_M_Priviliges_Emails = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    client = Client()
    url = reverse("PizzaDeliverySystem_EmailTemplate_create")
    data = {
        "Type": "text",
        "M_T_M_Priviliges_Emails": M_T_M_Priviliges_Emails.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_EmailTemplate_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_EmailTemplate()
    url = reverse("PizzaDeliverySystem_EmailTemplate_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_EmailTemplate_update_view():
    M_T_M_Priviliges_Emails = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_EmailTemplate()
    url = reverse("PizzaDeliverySystem_EmailTemplate_update", args=[instance.pk, ])
    data = {
        "Type": "text",
        "M_T_M_Priviliges_Emails": M_T_M_Priviliges_Emails.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_PriviligeLevel_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    instance2 = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    client = Client()
    url = reverse("PizzaDeliverySystem_PriviligeLevel_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_PriviligeLevel_create_view():
    M_T_M_Priviligies_Emails2 = test_helpers.create_PizzaDeliverySystem_EmailTemplate()
    client = Client()
    url = reverse("PizzaDeliverySystem_PriviligeLevel_create")
    data = {
        "Name": "text",
        "GrantsAccessTo": "text",
        "M_T_M_Priviligies_Emails2": M_T_M_Priviligies_Emails2.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_PriviligeLevel_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    url = reverse("PizzaDeliverySystem_PriviligeLevel_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_PriviligeLevel_update_view():
    M_T_M_Priviligies_Emails2 = test_helpers.create_PizzaDeliverySystem_EmailTemplate()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    url = reverse("PizzaDeliverySystem_PriviligeLevel_update", args=[instance.pk, ])
    data = {
        "Name": "text",
        "GrantsAccessTo": "text",
        "M_T_M_Priviligies_Emails2": M_T_M_Priviligies_Emails2.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Transaction_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_Transaction()
    instance2 = test_helpers.create_PizzaDeliverySystem_Transaction()
    client = Client()
    url = reverse("PizzaDeliverySystem_Transaction_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Transaction_create_view():
    O_T_O_Order_Transaction = test_helpers.create_PizzaDeliverySystem_Order()
    client = Client()
    url = reverse("PizzaDeliverySystem_Transaction_create")
    data = {
        "PaymentType": "text",
        "WasPayback": true,
        "PaymentOption": "text",
        "Amount": 1.0f,
        "Currency": "text",
        "O_T_O_Order_Transaction": O_T_O_Order_Transaction.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Transaction_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Transaction()
    url = reverse("PizzaDeliverySystem_Transaction_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Transaction_update_view():
    O_T_O_Order_Transaction = test_helpers.create_PizzaDeliverySystem_Order()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Transaction()
    url = reverse("PizzaDeliverySystem_Transaction_update", args=[instance.pk, ])
    data = {
        "PaymentType": "text",
        "WasPayback": true,
        "PaymentOption": "text",
        "Amount": 1.0f,
        "Currency": "text",
        "O_T_O_Order_Transaction": O_T_O_Order_Transaction.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_OrderItem_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_OrderItem()
    instance2 = test_helpers.create_PizzaDeliverySystem_OrderItem()
    client = Client()
    url = reverse("PizzaDeliverySystem_OrderItem_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_OrderItem_create_view():
    O_T_M_Order_OrderItems = test_helpers.create_PizzaDeliverySystem_Order()
    O_T_M_Product_OrderItems2 = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    O_T_M_Product_OrderItems = test_helpers.create_PizzaDeliverySystem_DrinkProduct()
    client = Client()
    url = reverse("PizzaDeliverySystem_OrderItem_create")
    data = {
        "Discount": 1.0f,
        "O_T_M_Order_OrderItems": O_T_M_Order_OrderItems.pk,
        "O_T_M_Product_OrderItems2": O_T_M_Product_OrderItems2.pk,
        "O_T_M_Product_OrderItems": O_T_M_Product_OrderItems.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_OrderItem_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_OrderItem()
    url = reverse("PizzaDeliverySystem_OrderItem_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_OrderItem_update_view():
    O_T_M_Order_OrderItems = test_helpers.create_PizzaDeliverySystem_Order()
    O_T_M_Product_OrderItems2 = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    O_T_M_Product_OrderItems = test_helpers.create_PizzaDeliverySystem_DrinkProduct()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_OrderItem()
    url = reverse("PizzaDeliverySystem_OrderItem_update", args=[instance.pk, ])
    data = {
        "Discount": 1.0f,
        "O_T_M_Order_OrderItems": O_T_M_Order_OrderItems.pk,
        "O_T_M_Product_OrderItems2": O_T_M_Product_OrderItems2.pk,
        "O_T_M_Product_OrderItems": O_T_M_Product_OrderItems.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Address_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_Address()
    instance2 = test_helpers.create_PizzaDeliverySystem_Address()
    client = Client()
    url = reverse("PizzaDeliverySystem_Address_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Address_create_view():
    O_T_M_User_Adresses = test_helpers.create_User()
    client = Client()
    url = reverse("PizzaDeliverySystem_Address_create")
    data = {
        "AddressType": "text",
        "DoorNumberAndOthers": "text",
        "City": "text",
        "ZipCode": "text",
        "StreetAndStreetNumber": "text",
        "O_T_M_User_Adresses": O_T_M_User_Adresses.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Address_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Address()
    url = reverse("PizzaDeliverySystem_Address_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Address_update_view():
    O_T_M_User_Adresses = test_helpers.create_User()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Address()
    url = reverse("PizzaDeliverySystem_Address_update", args=[instance.pk, ])
    data = {
        "AddressType": "text",
        "DoorNumberAndOthers": "text",
        "City": "text",
        "ZipCode": "text",
        "StreetAndStreetNumber": "text",
        "O_T_M_User_Adresses": O_T_M_User_Adresses.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Ingredient_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_Ingredient()
    instance2 = test_helpers.create_PizzaDeliverySystem_Ingredient()
    client = Client()
    url = reverse("PizzaDeliverySystem_Ingredient_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Ingredient_create_view():
    FoodProduct_To_Ingredient = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    client = Client()
    url = reverse("PizzaDeliverySystem_Ingredient_create")
    data = {
        "RemainingAmountInInventory": 1.0f,
        "FatsPerServing": 1.0f,
        "PricePerServing": 1.0f,
        "isTopping": true,
        "ProteinPerServing": 1.0f,
        "IsAllergen": true,
        "CarbsPerServing": 1.0f,
        "DairyFree": true,
        "Vegan": true,
        "FoodProduct_To_Ingredient": FoodProduct_To_Ingredient.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Ingredient_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Ingredient()
    url = reverse("PizzaDeliverySystem_Ingredient_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Ingredient_update_view():
    FoodProduct_To_Ingredient = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Ingredient()
    url = reverse("PizzaDeliverySystem_Ingredient_update", args=[instance.pk, ])
    data = {
        "RemainingAmountInInventory": 1.0f,
        "FatsPerServing": 1.0f,
        "PricePerServing": 1.0f,
        "isTopping": true,
        "ProteinPerServing": 1.0f,
        "IsAllergen": true,
        "CarbsPerServing": 1.0f,
        "DairyFree": true,
        "Vegan": true,
        "FoodProduct_To_Ingredient": FoodProduct_To_Ingredient.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Courier_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_Courier()
    instance2 = test_helpers.create_PizzaDeliverySystem_Courier()
    client = Client()
    url = reverse("PizzaDeliverySystem_Courier_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Courier_create_view():
    client = Client()
    url = reverse("PizzaDeliverySystem_Courier_create")
    data = {
        "Phone": "text",
        "Name": "text",
        "GpsCoordinates": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Courier_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Courier()
    url = reverse("PizzaDeliverySystem_Courier_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Courier_update_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Courier()
    url = reverse("PizzaDeliverySystem_Courier_update", args=[instance.pk, ])
    data = {
        "Phone": "text",
        "Name": "text",
        "GpsCoordinates": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Order_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_Order()
    instance2 = test_helpers.create_PizzaDeliverySystem_Order()
    client = Client()
    url = reverse("PizzaDeliverySystem_Order_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Order_create_view():
    O_T_O_Transaction_Order = test_helpers.create_PizzaDeliverySystem_Transaction()
    Courier_Orders = test_helpers.create_PizzaDeliverySystem_Courier()
    O_T_M_User_Orders = test_helpers.create_User()
    client = Client()
    url = reverse("PizzaDeliverySystem_Order_create")
    data = {
        "DeliveryDate": datetime.now(),
        "ExpectedGivingToCourierDate": datetime.now(),
        "Status": "text",
        "GivenToCourierDate": datetime.now(),
        "Comment": "text",
        "Discount": 1.0f,
        "ExpectedDeliveryDate": datetime.now(),
        "O_T_O_Transaction_Order": O_T_O_Transaction_Order.pk,
        "Courier_Orders": Courier_Orders.pk,
        "O_T_M_User_Orders": O_T_M_User_Orders.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Order_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Order()
    url = reverse("PizzaDeliverySystem_Order_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Order_update_view():
    O_T_O_Transaction_Order = test_helpers.create_PizzaDeliverySystem_Transaction()
    Courier_Orders = test_helpers.create_PizzaDeliverySystem_Courier()
    O_T_M_User_Orders = test_helpers.create_User()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_Order()
    url = reverse("PizzaDeliverySystem_Order_update", args=[instance.pk, ])
    data = {
        "DeliveryDate": datetime.now(),
        "ExpectedGivingToCourierDate": datetime.now(),
        "Status": "text",
        "GivenToCourierDate": datetime.now(),
        "Comment": "text",
        "Discount": 1.0f,
        "ExpectedDeliveryDate": datetime.now(),
        "O_T_O_Transaction_Order": O_T_O_Transaction_Order.pk,
        "Courier_Orders": Courier_Orders.pk,
        "O_T_M_User_Orders": O_T_M_User_Orders.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_FoodProduct_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    instance2 = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    client = Client()
    url = reverse("PizzaDeliverySystem_FoodProduct_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_FoodProduct_create_view():
    FoodProduct_To_Ingredient_2 = test_helpers.create_PizzaDeliverySystem_Ingredient()
    client = Client()
    url = reverse("PizzaDeliverySystem_FoodProduct_create")
    data = {
        "Vegan": true,
        "Vegetarian": true,
        "GlutenFree": true,
        "FoodProduct_To_Ingredient_2": FoodProduct_To_Ingredient_2.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_FoodProduct_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    url = reverse("PizzaDeliverySystem_FoodProduct_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_FoodProduct_update_view():
    FoodProduct_To_Ingredient_2 = test_helpers.create_PizzaDeliverySystem_Ingredient()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_FoodProduct()
    url = reverse("PizzaDeliverySystem_FoodProduct_update", args=[instance.pk, ])
    data = {
        "Vegan": true,
        "Vegetarian": true,
        "GlutenFree": true,
        "FoodProduct_To_Ingredient_2": FoodProduct_To_Ingredient_2.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_DrinkProduct_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_DrinkProduct()
    instance2 = test_helpers.create_PizzaDeliverySystem_DrinkProduct()
    client = Client()
    url = reverse("PizzaDeliverySystem_DrinkProduct_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_DrinkProduct_create_view():
    client = Client()
    url = reverse("PizzaDeliverySystem_DrinkProduct_create")
    data = {
        "ContainsCaffeine": true,
        "Calories": 1,
        "SugarContent": 1,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_DrinkProduct_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_DrinkProduct()
    url = reverse("PizzaDeliverySystem_DrinkProduct_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_DrinkProduct_update_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_DrinkProduct()
    url = reverse("PizzaDeliverySystem_DrinkProduct_update", args=[instance.pk, ])
    data = {
        "ContainsCaffeine": true,
        "Calories": 1,
        "SugarContent": 1,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_User_list_view():
    instance1 = test_helpers.create_PizzaDeliverySystem_User()
    instance2 = test_helpers.create_PizzaDeliverySystem_User()
    client = Client()
    url = reverse("PizzaDeliverySystem_User_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_User_create_view():
    M_T_O_PriviligeLevel_User = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    client = Client()
    url = reverse("PizzaDeliverySystem_User_create")
    data = {
        "emailToken": "text",
        "M_T_O_PriviligeLevel_User": M_T_O_PriviligeLevel_User.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_User_detail_view():
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_User()
    url = reverse("PizzaDeliverySystem_User_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_User_update_view():
    M_T_O_PriviligeLevel_User = test_helpers.create_PizzaDeliverySystem_PriviligeLevel()
    client = Client()
    instance = test_helpers.create_PizzaDeliverySystem_User()
    url = reverse("PizzaDeliverySystem_User_update", args=[instance.pk, ])
    data = {
        "emailToken": "text",
        "M_T_O_PriviligeLevel_User": M_T_O_PriviligeLevel_User.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302
