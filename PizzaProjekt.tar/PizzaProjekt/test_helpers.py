import random
import string

from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType
from datetime import datetime

from PizzaDeliverySystem import models as PizzaDeliverySystem_models


def random_string(length=10):
    # Create a random string of length length
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for i in range(length))


def create_User(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_AbstractUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractUser.objects.create(**defaults)


def create_AbstractBaseUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractBaseUser.objects.create(**defaults)


def create_Group(**kwargs):
    defaults = {
        "name": "%s_group" % random_string(5),
    }
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_ContentType(**kwargs):
    defaults = {
    }
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_PizzaDeliverySystem_EmailTemplate(**kwargs):
    defaults = {}
    defaults["Type"] = ""
    if "M_T_M_Priviliges_Emails" not in kwargs:
        defaults["M_T_M_Priviliges_Emails"] = create_PizzaDeliverySystem_PriviligeLevel()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.EmailTemplate.objects.create(**defaults)
def create_PizzaDeliverySystem_PriviligeLevel(**kwargs):
    defaults = {}
    defaults["Name"] = ""
    defaults["GrantsAccessTo"] = ""
    if "M_T_M_Priviligies_Emails2" not in kwargs:
        defaults["M_T_M_Priviligies_Emails2"] = create_PizzaDeliverySystem_EmailTemplate()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.PriviligeLevel.objects.create(**defaults)
def create_PizzaDeliverySystem_Transaction(**kwargs):
    defaults = {}
    defaults["PaymentType"] = ""
    defaults["WasPayback"] = ""
    defaults["PaymentOption"] = ""
    defaults["Amount"] = ""
    defaults["Currency"] = ""
    if "O_T_O_Order_Transaction" not in kwargs:
        defaults["O_T_O_Order_Transaction"] = create_PizzaDeliverySystem_Order()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.Transaction.objects.create(**defaults)
def create_PizzaDeliverySystem_OrderItem(**kwargs):
    defaults = {}
    defaults["Discount"] = ""
    if "O_T_M_Order_OrderItems" not in kwargs:
        defaults["O_T_M_Order_OrderItems"] = create_PizzaDeliverySystem_Order()
    if "O_T_M_Product_OrderItems2" not in kwargs:
        defaults["O_T_M_Product_OrderItems2"] = create_PizzaDeliverySystem_FoodProduct()
    if "O_T_M_Product_OrderItems" not in kwargs:
        defaults["O_T_M_Product_OrderItems"] = create_PizzaDeliverySystem_DrinkProduct()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.OrderItem.objects.create(**defaults)
def create_PizzaDeliverySystem_Address(**kwargs):
    defaults = {}
    defaults["AddressType"] = ""
    defaults["DoorNumberAndOthers"] = ""
    defaults["City"] = ""
    defaults["ZipCode"] = ""
    defaults["StreetAndStreetNumber"] = ""
    if "O_T_M_User_Adresses" not in kwargs:
        defaults["O_T_M_User_Adresses"] = create_User()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.Address.objects.create(**defaults)
def create_PizzaDeliverySystem_Ingredient(**kwargs):
    defaults = {}
    defaults["RemainingAmountInInventory"] = ""
    defaults["FatsPerServing"] = ""
    defaults["PricePerServing"] = ""
    defaults["isTopping"] = ""
    defaults["ProteinPerServing"] = ""
    defaults["IsAllergen"] = ""
    defaults["CarbsPerServing"] = ""
    defaults["DairyFree"] = ""
    defaults["Vegan"] = ""
    if "FoodProduct_To_Ingredient" not in kwargs:
        defaults["FoodProduct_To_Ingredient"] = create_PizzaDeliverySystem_FoodProduct()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.Ingredient.objects.create(**defaults)
def create_PizzaDeliverySystem_Courier(**kwargs):
    defaults = {}
    defaults["Phone"] = ""
    defaults["Name"] = ""
    defaults["GpsCoordinates"] = ""
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.Courier.objects.create(**defaults)
def create_PizzaDeliverySystem_Order(**kwargs):
    defaults = {}
    defaults["DeliveryDate"] = datetime.now()
    defaults["ExpectedGivingToCourierDate"] = datetime.now()
    defaults["Status"] = ""
    defaults["GivenToCourierDate"] = datetime.now()
    defaults["Comment"] = ""
    defaults["Discount"] = ""
    defaults["ExpectedDeliveryDate"] = datetime.now()
    if "O_T_O_Transaction_Order" not in kwargs:
        defaults["O_T_O_Transaction_Order"] = create_PizzaDeliverySystem_Transaction()
    if "Courier_Orders" not in kwargs:
        defaults["Courier_Orders"] = create_PizzaDeliverySystem_Courier()
    if "O_T_M_User_Orders" not in kwargs:
        defaults["O_T_M_User_Orders"] = create_User()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.Order.objects.create(**defaults)
def create_PizzaDeliverySystem_FoodProduct(**kwargs):
    defaults = {}
    defaults["Vegan"] = ""
    defaults["Vegetarian"] = ""
    defaults["GlutenFree"] = ""
    defaults["Name"] = "text"
    defaults["Description"] = "text"
    defaults["Size"] = "text"
    defaults["last_updated"] = datetime.now()
    defaults["created"] = datetime.now()
    defaults["Price"] = 1.0f
    defaults["PublicProductId"] = 1
    if "FoodProduct_To_Ingredient_2" not in kwargs:
        defaults["FoodProduct_To_Ingredient_2"] = create_PizzaDeliverySystem_Ingredient()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.FoodProduct.objects.create(**defaults)
def create_PizzaDeliverySystem_DrinkProduct(**kwargs):
    defaults = {}
    defaults["ContainsCaffeine"] = ""
    defaults["Calories"] = ""
    defaults["SugarContent"] = ""
    defaults["Name"] = "text"
    defaults["Description"] = "text"
    defaults["Size"] = "text"
    defaults["last_updated"] = datetime.now()
    defaults["created"] = datetime.now()
    defaults["Price"] = 1.0f
    defaults["PublicProductId"] = 1
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.DrinkProduct.objects.create(**defaults)
def create_PizzaDeliverySystem_User(**kwargs):
    defaults = {}
    defaults["emailToken"] = ""
    defaults["username"] = "username"
    defaults["email"] = "username@tempurl.com"
    if "M_T_O_PriviligeLevel_User" not in kwargs:
        defaults["M_T_O_PriviligeLevel_User"] = create_PizzaDeliverySystem_PriviligeLevel()
    defaults.update(**kwargs)
    return PizzaDeliverySystem_models.User.objects.create(**defaults)
