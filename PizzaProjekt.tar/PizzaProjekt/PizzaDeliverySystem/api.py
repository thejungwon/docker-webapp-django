from rest_framework import viewsets, permissions

from . import serializers
from . import models


class ProductViewSet(viewsets.ModelViewSet):
    """ViewSet for the Product class"""

    queryset = models.Product.objects.all()
    serializer_class = serializers.ProductSerializer
    permission_classes = [permissions.IsAuthenticated]


class EmailTemplateViewSet(viewsets.ModelViewSet):
    """ViewSet for the EmailTemplate class"""

    queryset = models.EmailTemplate.objects.all()
    serializer_class = serializers.EmailTemplateSerializer
    permission_classes = [permissions.IsAuthenticated]


class PriviligeLevelViewSet(viewsets.ModelViewSet):
    """ViewSet for the PriviligeLevel class"""

    queryset = models.PriviligeLevel.objects.all()
    serializer_class = serializers.PriviligeLevelSerializer
    permission_classes = [permissions.IsAuthenticated]


class TransactionViewSet(viewsets.ModelViewSet):
    """ViewSet for the Transaction class"""

    queryset = models.Transaction.objects.all()
    serializer_class = serializers.TransactionSerializer
    permission_classes = [permissions.IsAuthenticated]


class OrderItemViewSet(viewsets.ModelViewSet):
    """ViewSet for the OrderItem class"""

    queryset = models.OrderItem.objects.all()
    serializer_class = serializers.OrderItemSerializer
    permission_classes = [permissions.IsAuthenticated]


class AddressViewSet(viewsets.ModelViewSet):
    """ViewSet for the Address class"""

    queryset = models.Address.objects.all()
    serializer_class = serializers.AddressSerializer
    permission_classes = [permissions.IsAuthenticated]


class IngredientViewSet(viewsets.ModelViewSet):
    """ViewSet for the Ingredient class"""

    queryset = models.Ingredient.objects.all()
    serializer_class = serializers.IngredientSerializer
    permission_classes = [permissions.IsAuthenticated]


class CourierViewSet(viewsets.ModelViewSet):
    """ViewSet for the Courier class"""

    queryset = models.Courier.objects.all()
    serializer_class = serializers.CourierSerializer
    permission_classes = [permissions.IsAuthenticated]


class OrderViewSet(viewsets.ModelViewSet):
    """ViewSet for the Order class"""

    queryset = models.Order.objects.all()
    serializer_class = serializers.OrderSerializer
    permission_classes = [permissions.IsAuthenticated]


class FoodProductViewSet(viewsets.ModelViewSet):
    """ViewSet for the FoodProduct class"""

    queryset = models.FoodProduct.objects.all()
    serializer_class = serializers.FoodProductSerializer
    permission_classes = [permissions.IsAuthenticated]


class DrinkProductViewSet(viewsets.ModelViewSet):
    """ViewSet for the DrinkProduct class"""

    queryset = models.DrinkProduct.objects.all()
    serializer_class = serializers.DrinkProductSerializer
    permission_classes = [permissions.IsAuthenticated]


class UserViewSet(viewsets.ModelViewSet):
    """ViewSet for the User class"""

    queryset = models.User.objects.all()
    serializer_class = serializers.UserSerializer
    permission_classes = [permissions.IsAuthenticated]
