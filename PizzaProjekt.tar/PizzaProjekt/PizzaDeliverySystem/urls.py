from django.urls import path, include
from rest_framework import routers

from . import api
from . import views


router = routers.DefaultRouter()
router.register("Product", api.ProductViewSet)
router.register("EmailTemplate", api.EmailTemplateViewSet)
router.register("PriviligeLevel", api.PriviligeLevelViewSet)
router.register("Transaction", api.TransactionViewSet)
router.register("OrderItem", api.OrderItemViewSet)
router.register("Address", api.AddressViewSet)
router.register("Ingredient", api.IngredientViewSet)
router.register("Courier", api.CourierViewSet)
router.register("Order", api.OrderViewSet)
router.register("FoodProduct", api.FoodProductViewSet)
router.register("DrinkProduct", api.DrinkProductViewSet)
router.register("User", api.UserViewSet)

urlpatterns = (
    path("api/v1/", include(router.urls)),
    path("PizzaDeliverySystem/Product/", views.ProductListView.as_view(), name="PizzaDeliverySystem_Product_list"),
    path("PizzaDeliverySystem/Product/create/", views.ProductCreateView.as_view(), name="PizzaDeliverySystem_Product_create"),
    path("PizzaDeliverySystem/Product/detail/<int:pk>/", views.ProductDetailView.as_view(), name="PizzaDeliverySystem_Product_detail"),
    path("PizzaDeliverySystem/Product/update/<int:pk>/", views.ProductUpdateView.as_view(), name="PizzaDeliverySystem_Product_update"),
    path("PizzaDeliverySystem/EmailTemplate/", views.EmailTemplateListView.as_view(), name="PizzaDeliverySystem_EmailTemplate_list"),
    path("PizzaDeliverySystem/EmailTemplate/create/", views.EmailTemplateCreateView.as_view(), name="PizzaDeliverySystem_EmailTemplate_create"),
    path("PizzaDeliverySystem/EmailTemplate/detail/<int:pk>/", views.EmailTemplateDetailView.as_view(), name="PizzaDeliverySystem_EmailTemplate_detail"),
    path("PizzaDeliverySystem/EmailTemplate/update/<int:pk>/", views.EmailTemplateUpdateView.as_view(), name="PizzaDeliverySystem_EmailTemplate_update"),
    path("PizzaDeliverySystem/PriviligeLevel/", views.PriviligeLevelListView.as_view(), name="PizzaDeliverySystem_PriviligeLevel_list"),
    path("PizzaDeliverySystem/PriviligeLevel/create/", views.PriviligeLevelCreateView.as_view(), name="PizzaDeliverySystem_PriviligeLevel_create"),
    path("PizzaDeliverySystem/PriviligeLevel/detail/<int:pk>/", views.PriviligeLevelDetailView.as_view(), name="PizzaDeliverySystem_PriviligeLevel_detail"),
    path("PizzaDeliverySystem/PriviligeLevel/update/<int:pk>/", views.PriviligeLevelUpdateView.as_view(), name="PizzaDeliverySystem_PriviligeLevel_update"),
    path("PizzaDeliverySystem/Transaction/", views.TransactionListView.as_view(), name="PizzaDeliverySystem_Transaction_list"),
    path("PizzaDeliverySystem/Transaction/create/", views.TransactionCreateView.as_view(), name="PizzaDeliverySystem_Transaction_create"),
    path("PizzaDeliverySystem/Transaction/detail/<int:pk>/", views.TransactionDetailView.as_view(), name="PizzaDeliverySystem_Transaction_detail"),
    path("PizzaDeliverySystem/Transaction/update/<int:pk>/", views.TransactionUpdateView.as_view(), name="PizzaDeliverySystem_Transaction_update"),
    path("PizzaDeliverySystem/OrderItem/", views.OrderItemListView.as_view(), name="PizzaDeliverySystem_OrderItem_list"),
    path("PizzaDeliverySystem/OrderItem/create/", views.OrderItemCreateView.as_view(), name="PizzaDeliverySystem_OrderItem_create"),
    path("PizzaDeliverySystem/OrderItem/detail/<int:pk>/", views.OrderItemDetailView.as_view(), name="PizzaDeliverySystem_OrderItem_detail"),
    path("PizzaDeliverySystem/OrderItem/update/<int:pk>/", views.OrderItemUpdateView.as_view(), name="PizzaDeliverySystem_OrderItem_update"),
    path("PizzaDeliverySystem/Address/", views.AddressListView.as_view(), name="PizzaDeliverySystem_Address_list"),
    path("PizzaDeliverySystem/Address/create/", views.AddressCreateView.as_view(), name="PizzaDeliverySystem_Address_create"),
    path("PizzaDeliverySystem/Address/detail/<int:pk>/", views.AddressDetailView.as_view(), name="PizzaDeliverySystem_Address_detail"),
    path("PizzaDeliverySystem/Address/update/<int:pk>/", views.AddressUpdateView.as_view(), name="PizzaDeliverySystem_Address_update"),
    path("PizzaDeliverySystem/Ingredient/", views.IngredientListView.as_view(), name="PizzaDeliverySystem_Ingredient_list"),
    path("PizzaDeliverySystem/Ingredient/create/", views.IngredientCreateView.as_view(), name="PizzaDeliverySystem_Ingredient_create"),
    path("PizzaDeliverySystem/Ingredient/detail/<int:pk>/", views.IngredientDetailView.as_view(), name="PizzaDeliverySystem_Ingredient_detail"),
    path("PizzaDeliverySystem/Ingredient/update/<int:pk>/", views.IngredientUpdateView.as_view(), name="PizzaDeliverySystem_Ingredient_update"),
    path("PizzaDeliverySystem/Courier/", views.CourierListView.as_view(), name="PizzaDeliverySystem_Courier_list"),
    path("PizzaDeliverySystem/Courier/create/", views.CourierCreateView.as_view(), name="PizzaDeliverySystem_Courier_create"),
    path("PizzaDeliverySystem/Courier/detail/<int:pk>/", views.CourierDetailView.as_view(), name="PizzaDeliverySystem_Courier_detail"),
    path("PizzaDeliverySystem/Courier/update/<int:pk>/", views.CourierUpdateView.as_view(), name="PizzaDeliverySystem_Courier_update"),
    path("PizzaDeliverySystem/Order/", views.OrderListView.as_view(), name="PizzaDeliverySystem_Order_list"),
    path("PizzaDeliverySystem/Order/create/", views.OrderCreateView.as_view(), name="PizzaDeliverySystem_Order_create"),
    path("PizzaDeliverySystem/Order/detail/<int:pk>/", views.OrderDetailView.as_view(), name="PizzaDeliverySystem_Order_detail"),
    path("PizzaDeliverySystem/Order/update/<int:pk>/", views.OrderUpdateView.as_view(), name="PizzaDeliverySystem_Order_update"),
    path("PizzaDeliverySystem/FoodProduct/", views.FoodProductListView.as_view(), name="PizzaDeliverySystem_FoodProduct_list"),
    path("PizzaDeliverySystem/FoodProduct/create/", views.FoodProductCreateView.as_view(), name="PizzaDeliverySystem_FoodProduct_create"),
    path("PizzaDeliverySystem/FoodProduct/detail/<int:pk>/", views.FoodProductDetailView.as_view(), name="PizzaDeliverySystem_FoodProduct_detail"),
    path("PizzaDeliverySystem/FoodProduct/update/<int:pk>/", views.FoodProductUpdateView.as_view(), name="PizzaDeliverySystem_FoodProduct_update"),
    path("PizzaDeliverySystem/DrinkProduct/", views.DrinkProductListView.as_view(), name="PizzaDeliverySystem_DrinkProduct_list"),
    path("PizzaDeliverySystem/DrinkProduct/create/", views.DrinkProductCreateView.as_view(), name="PizzaDeliverySystem_DrinkProduct_create"),
    path("PizzaDeliverySystem/DrinkProduct/detail/<int:pk>/", views.DrinkProductDetailView.as_view(), name="PizzaDeliverySystem_DrinkProduct_detail"),
    path("PizzaDeliverySystem/DrinkProduct/update/<int:pk>/", views.DrinkProductUpdateView.as_view(), name="PizzaDeliverySystem_DrinkProduct_update"),
    path("PizzaDeliverySystem/User/", views.UserListView.as_view(), name="PizzaDeliverySystem_User_list"),
    path("PizzaDeliverySystem/User/create/", views.UserCreateView.as_view(), name="PizzaDeliverySystem_User_create"),
    path("PizzaDeliverySystem/User/detail/<int:pk>/", views.UserDetailView.as_view(), name="PizzaDeliverySystem_User_detail"),
    path("PizzaDeliverySystem/User/update/<int:pk>/", views.UserUpdateView.as_view(), name="PizzaDeliverySystem_User_update"),
)
