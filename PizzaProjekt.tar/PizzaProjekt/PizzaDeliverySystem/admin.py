from django.contrib import admin
from django import forms

from . import models


class ProductAdminForm(forms.ModelForm):

    class Meta:
        model = models.Product
        fields = "__all__"


class ProductAdmin(admin.ModelAdmin):
    form = ProductAdminForm
    list_display = [
        "Name",
        "Description",
        "Size",
        "last_updated",
        "created",
        "Price",
        "PublicProductId",
    ]
    readonly_fields = [
        "Name",
        "Description",
        "Size",
        "last_updated",
        "created",
        "Price",
        "PublicProductId",
    ]


class EmailTemplateAdminForm(forms.ModelForm):

    class Meta:
        model = models.EmailTemplate
        fields = "__all__"


class EmailTemplateAdmin(admin.ModelAdmin):
    form = EmailTemplateAdminForm
    list_display = [
        "created",
        "last_updated",
        "Type",
    ]
    readonly_fields = [
        "created",
        "last_updated",
        "Type",
    ]


class PriviligeLevelAdminForm(forms.ModelForm):

    class Meta:
        model = models.PriviligeLevel
        fields = "__all__"


class PriviligeLevelAdmin(admin.ModelAdmin):
    form = PriviligeLevelAdminForm
    list_display = [
        "Name",
        "created",
        "last_updated",
        "GrantsAccessTo",
    ]
    readonly_fields = [
        "Name",
        "created",
        "last_updated",
        "GrantsAccessTo",
    ]


class TransactionAdminForm(forms.ModelForm):

    class Meta:
        model = models.Transaction
        fields = "__all__"


class TransactionAdmin(admin.ModelAdmin):
    form = TransactionAdminForm
    list_display = [
        "PaymentType",
        "last_updated",
        "WasPayback",
        "PaymentOption",
        "Amount",
        "Currency",
        "created",
    ]
    readonly_fields = [
        "PaymentType",
        "last_updated",
        "WasPayback",
        "PaymentOption",
        "Amount",
        "Currency",
        "created",
    ]


class OrderItemAdminForm(forms.ModelForm):

    class Meta:
        model = models.OrderItem
        fields = "__all__"


class OrderItemAdmin(admin.ModelAdmin):
    form = OrderItemAdminForm
    list_display = [
        "Discount",
        "created",
        "last_updated",
    ]
    readonly_fields = [
        "Discount",
        "created",
        "last_updated",
    ]


class AddressAdminForm(forms.ModelForm):

    class Meta:
        model = models.Address
        fields = "__all__"


class AddressAdmin(admin.ModelAdmin):
    form = AddressAdminForm
    list_display = [
        "last_updated",
        "AddressType",
        "created",
        "DoorNumberAndOthers",
        "City",
        "ZipCode",
        "StreetAndStreetNumber",
    ]
    readonly_fields = [
        "last_updated",
        "AddressType",
        "created",
        "DoorNumberAndOthers",
        "City",
        "ZipCode",
        "StreetAndStreetNumber",
    ]


class IngredientAdminForm(forms.ModelForm):

    class Meta:
        model = models.Ingredient
        fields = "__all__"


class IngredientAdmin(admin.ModelAdmin):
    form = IngredientAdminForm
    list_display = [
        "RemainingAmountInInventory",
        "FatsPerServing",
        "last_updated",
        "PricePerServing",
        "created",
        "isTopping",
        "ProteinPerServing",
        "IsAllergen",
        "CarbsPerServing",
        "DairyFree",
        "Vegan",
    ]
    readonly_fields = [
        "RemainingAmountInInventory",
        "FatsPerServing",
        "last_updated",
        "PricePerServing",
        "created",
        "isTopping",
        "ProteinPerServing",
        "IsAllergen",
        "CarbsPerServing",
        "DairyFree",
        "Vegan",
    ]


class CourierAdminForm(forms.ModelForm):

    class Meta:
        model = models.Courier
        fields = "__all__"


class CourierAdmin(admin.ModelAdmin):
    form = CourierAdminForm
    list_display = [
        "created",
        "Phone",
        "last_updated",
        "Name",
        "GpsCoordinates",
    ]
    readonly_fields = [
        "created",
        "Phone",
        "last_updated",
        "Name",
        "GpsCoordinates",
    ]


class OrderAdminForm(forms.ModelForm):

    class Meta:
        model = models.Order
        fields = "__all__"


class OrderAdmin(admin.ModelAdmin):
    form = OrderAdminForm
    list_display = [
        "DeliveryDate",
        "last_updated",
        "ExpectedGivingToCourierDate",
        "Status",
        "GivenToCourierDate",
        "created",
        "Comment",
        "Discount",
        "ExpectedDeliveryDate",
    ]
    readonly_fields = [
        "DeliveryDate",
        "last_updated",
        "ExpectedGivingToCourierDate",
        "Status",
        "GivenToCourierDate",
        "created",
        "Comment",
        "Discount",
        "ExpectedDeliveryDate",
    ]


class FoodProductAdminForm(forms.ModelForm):

    class Meta:
        model = models.FoodProduct
        fields = "__all__"


class FoodProductAdmin(admin.ModelAdmin):
    form = FoodProductAdminForm
    list_display = [
        "Vegan",
        "last_updated",
        "created",
        "Vegetarian",
        "GlutenFree",
    ]
    readonly_fields = [
        "Vegan",
        "last_updated",
        "created",
        "Vegetarian",
        "GlutenFree",
    ]


class DrinkProductAdminForm(forms.ModelForm):

    class Meta:
        model = models.DrinkProduct
        fields = "__all__"


class DrinkProductAdmin(admin.ModelAdmin):
    form = DrinkProductAdminForm
    list_display = [
        "ContainsCaffeine",
        "last_updated",
        "Calories",
        "created",
        "SugarContent",
    ]
    readonly_fields = [
        "ContainsCaffeine",
        "last_updated",
        "Calories",
        "created",
        "SugarContent",
    ]


class UserAdminForm(forms.ModelForm):

    class Meta:
        model = models.User
        fields = "__all__"


class UserAdmin(admin.ModelAdmin):
    form = UserAdminForm
    list_display = [
        "emailToken",
        "created",
        "last_updated",
    ]
    readonly_fields = [
        "emailToken",
        "created",
        "last_updated",
    ]


admin.site.register(models.Product, ProductAdmin)
admin.site.register(models.EmailTemplate, EmailTemplateAdmin)
admin.site.register(models.PriviligeLevel, PriviligeLevelAdmin)
admin.site.register(models.Transaction, TransactionAdmin)
admin.site.register(models.OrderItem, OrderItemAdmin)
admin.site.register(models.Address, AddressAdmin)
admin.site.register(models.Ingredient, IngredientAdmin)
admin.site.register(models.Courier, CourierAdmin)
admin.site.register(models.Order, OrderAdmin)
admin.site.register(models.FoodProduct, FoodProductAdmin)
admin.site.register(models.DrinkProduct, DrinkProductAdmin)
admin.site.register(models.User, UserAdmin)
