from django import forms
from . import models


class EmailTemplateForm(forms.ModelForm):
    class Meta:
        model = models.EmailTemplate
        fields = [
            "Type",
            "M_T_M_Priviliges_Emails",
        ]


class PriviligeLevelForm(forms.ModelForm):
    class Meta:
        model = models.PriviligeLevel
        fields = [
            "Name",
            "GrantsAccessTo",
            "M_T_M_Priviligies_Emails2",
        ]


class TransactionForm(forms.ModelForm):
    class Meta:
        model = models.Transaction
        fields = [
            "PaymentType",
            "WasPayback",
            "PaymentOption",
            "Amount",
            "Currency",
            "O_T_O_Order_Transaction",
        ]


class OrderItemForm(forms.ModelForm):
    class Meta:
        model = models.OrderItem
        fields = [
            "Discount",
            "O_T_M_Order_OrderItems",
            "O_T_M_Product_OrderItems2",
            "O_T_M_Product_OrderItems",
        ]


class AddressForm(forms.ModelForm):
    class Meta:
        model = models.Address
        fields = [
            "AddressType",
            "DoorNumberAndOthers",
            "City",
            "ZipCode",
            "StreetAndStreetNumber",
            "O_T_M_User_Adresses",
        ]


class IngredientForm(forms.ModelForm):
    class Meta:
        model = models.Ingredient
        fields = [
            "RemainingAmountInInventory",
            "FatsPerServing",
            "PricePerServing",
            "isTopping",
            "ProteinPerServing",
            "IsAllergen",
            "CarbsPerServing",
            "DairyFree",
            "Vegan",
            "FoodProduct_To_Ingredient",
        ]


class CourierForm(forms.ModelForm):
    class Meta:
        model = models.Courier
        fields = [
            "Phone",
            "Name",
            "GpsCoordinates",
        ]


class OrderForm(forms.ModelForm):
    class Meta:
        model = models.Order
        fields = [
            "DeliveryDate",
            "ExpectedGivingToCourierDate",
            "Status",
            "GivenToCourierDate",
            "Comment",
            "Discount",
            "ExpectedDeliveryDate",
            "O_T_O_Transaction_Order",
            "Courier_Orders",
            "O_T_M_User_Orders",
        ]


class FoodProductForm(forms.ModelForm):
    class Meta:
        model = models.FoodProduct
        fields = [
            "Vegan",
            "Vegetarian",
            "GlutenFree",
            "FoodProduct_To_Ingredient_2",
        ]


class DrinkProductForm(forms.ModelForm):
    class Meta:
        model = models.DrinkProduct
        fields = [
            "ContainsCaffeine",
            "Calories",
            "SugarContent",
        ]


class UserForm(forms.ModelForm):
    class Meta:
        model = models.User
        fields = [
            "emailToken",
            "M_T_O_PriviligeLevel_User",
        ]
