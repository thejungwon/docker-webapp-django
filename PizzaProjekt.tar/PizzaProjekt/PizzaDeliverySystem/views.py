from django.views import generic
from . import models
from . import forms


class EmailTemplateListView(generic.ListView):
    model = models.EmailTemplate
    form_class = forms.EmailTemplateForm


class EmailTemplateCreateView(generic.CreateView):
    model = models.EmailTemplate
    form_class = forms.EmailTemplateForm


class EmailTemplateDetailView(generic.DetailView):
    model = models.EmailTemplate
    form_class = forms.EmailTemplateForm


class EmailTemplateUpdateView(generic.UpdateView):
    model = models.EmailTemplate
    form_class = forms.EmailTemplateForm
    pk_url_kwarg = "pk"


class PriviligeLevelListView(generic.ListView):
    model = models.PriviligeLevel
    form_class = forms.PriviligeLevelForm


class PriviligeLevelCreateView(generic.CreateView):
    model = models.PriviligeLevel
    form_class = forms.PriviligeLevelForm


class PriviligeLevelDetailView(generic.DetailView):
    model = models.PriviligeLevel
    form_class = forms.PriviligeLevelForm


class PriviligeLevelUpdateView(generic.UpdateView):
    model = models.PriviligeLevel
    form_class = forms.PriviligeLevelForm
    pk_url_kwarg = "pk"


class TransactionListView(generic.ListView):
    model = models.Transaction
    form_class = forms.TransactionForm


class TransactionCreateView(generic.CreateView):
    model = models.Transaction
    form_class = forms.TransactionForm


class TransactionDetailView(generic.DetailView):
    model = models.Transaction
    form_class = forms.TransactionForm


class TransactionUpdateView(generic.UpdateView):
    model = models.Transaction
    form_class = forms.TransactionForm
    pk_url_kwarg = "pk"


class OrderItemListView(generic.ListView):
    model = models.OrderItem
    form_class = forms.OrderItemForm


class OrderItemCreateView(generic.CreateView):
    model = models.OrderItem
    form_class = forms.OrderItemForm


class OrderItemDetailView(generic.DetailView):
    model = models.OrderItem
    form_class = forms.OrderItemForm


class OrderItemUpdateView(generic.UpdateView):
    model = models.OrderItem
    form_class = forms.OrderItemForm
    pk_url_kwarg = "pk"


class AddressListView(generic.ListView):
    model = models.Address
    form_class = forms.AddressForm


class AddressCreateView(generic.CreateView):
    model = models.Address
    form_class = forms.AddressForm


class AddressDetailView(generic.DetailView):
    model = models.Address
    form_class = forms.AddressForm


class AddressUpdateView(generic.UpdateView):
    model = models.Address
    form_class = forms.AddressForm
    pk_url_kwarg = "pk"


class IngredientListView(generic.ListView):
    model = models.Ingredient
    form_class = forms.IngredientForm


class IngredientCreateView(generic.CreateView):
    model = models.Ingredient
    form_class = forms.IngredientForm


class IngredientDetailView(generic.DetailView):
    model = models.Ingredient
    form_class = forms.IngredientForm


class IngredientUpdateView(generic.UpdateView):
    model = models.Ingredient
    form_class = forms.IngredientForm
    pk_url_kwarg = "pk"


class CourierListView(generic.ListView):
    model = models.Courier
    form_class = forms.CourierForm


class CourierCreateView(generic.CreateView):
    model = models.Courier
    form_class = forms.CourierForm


class CourierDetailView(generic.DetailView):
    model = models.Courier
    form_class = forms.CourierForm


class CourierUpdateView(generic.UpdateView):
    model = models.Courier
    form_class = forms.CourierForm
    pk_url_kwarg = "pk"


class OrderListView(generic.ListView):
    model = models.Order
    form_class = forms.OrderForm


class OrderCreateView(generic.CreateView):
    model = models.Order
    form_class = forms.OrderForm


class OrderDetailView(generic.DetailView):
    model = models.Order
    form_class = forms.OrderForm


class OrderUpdateView(generic.UpdateView):
    model = models.Order
    form_class = forms.OrderForm
    pk_url_kwarg = "pk"


class FoodProductListView(generic.ListView):
    model = models.FoodProduct
    form_class = forms.FoodProductForm


class FoodProductCreateView(generic.CreateView):
    model = models.FoodProduct
    form_class = forms.FoodProductForm


class FoodProductDetailView(generic.DetailView):
    model = models.FoodProduct
    form_class = forms.FoodProductForm


class FoodProductUpdateView(generic.UpdateView):
    model = models.FoodProduct
    form_class = forms.FoodProductForm
    pk_url_kwarg = "pk"


class DrinkProductListView(generic.ListView):
    model = models.DrinkProduct
    form_class = forms.DrinkProductForm


class DrinkProductCreateView(generic.CreateView):
    model = models.DrinkProduct
    form_class = forms.DrinkProductForm


class DrinkProductDetailView(generic.DetailView):
    model = models.DrinkProduct
    form_class = forms.DrinkProductForm


class DrinkProductUpdateView(generic.UpdateView):
    model = models.DrinkProduct
    form_class = forms.DrinkProductForm
    pk_url_kwarg = "pk"


class UserListView(generic.ListView):
    model = models.User
    form_class = forms.UserForm


class UserCreateView(generic.CreateView):
    model = models.User
    form_class = forms.UserForm


class UserDetailView(generic.DetailView):
    model = models.User
    form_class = forms.UserForm


class UserUpdateView(generic.UpdateView):
    model = models.User
    form_class = forms.UserForm
    pk_url_kwarg = "pk"
